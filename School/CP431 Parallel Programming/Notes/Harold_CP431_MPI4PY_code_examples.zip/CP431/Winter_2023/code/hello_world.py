#!/usr/bin/env python3
"""
Parallel Hello World
"""
from mpi4py import MPI

size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()
name = MPI.Get_processor_name()

print('Greetings. I am process {} of {} on {}'.format(rank, size, name ) )
