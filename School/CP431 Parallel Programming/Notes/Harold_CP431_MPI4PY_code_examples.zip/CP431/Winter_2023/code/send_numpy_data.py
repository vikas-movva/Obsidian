#!/usr/bin/env python3
"""
Send Numpy Data
"""

from mpi4py import MPI
import numpy

comm = MPI.COMM_WORLD
rank = comm.Get_rank()

# pass explicit MPI data types
if rank == 0 :
    data = numpy.random.randint(0,100, size=(2, 4), dtype='i')
    comm.Send( [ data, MPI.INT ] , dest=1, tag=77)
elif rank == 1 :
    data = numpy.empty ( (2,4), dtype='i' )
    comm.Recv( [ data, MPI.INT ],  source=0 , tag=77)
    print(data)

# automatic MPI data type discovery
if rank == 0 :
    data = numpy.random.randint(0,100, size=(2, 3, 4), dtype='i')
    comm.Send( data, dest=1, tag=13)
elif rank == 1 :
    data = numpy.empty( (2,3,4), dtype='i' )
    comm.Recv( data, source=0, tag=13)
    print(data)
