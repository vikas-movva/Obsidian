#!/bin/bash
#SBATCH --account=def-some-user
#SBATCH --nodes=2
#SBATCH --ntasks=8               # number of MPI processes
#SBATCH --mem-per-cpu=512M      # memory; default unit is megabytes
#SBATCH --time=0-00:15           # time (DD-HH:MM)

module load StdEnv/2020  intel/2020.1.217  openmpi/4.0.3 scipy-stack/2022a mpi4py/3.1.2 python/3.9
#export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK #Use this with multi-threaded code
echo 'Hello World Example'
srun ./hello_world.py              # mpirun or mpiexec also work
echo 'Send Python Data Example'
srun ./send_python_data.py
echo 'Send Numpy Data Example'
srun ./send_numpy_data.py


